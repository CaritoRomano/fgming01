<?php $__env->startSection('head'); ?>
	<title>Contacto</title>
	<meta name="description" content="Inicio">
	<meta name="keywords" content="FGMIngenieria, ingenieria">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
    	<h3>Contactame...</h3>
    </div>

    <?php echo e(Form::open(['route' => 'contacto.store', 'method' => 'POST'])); ?>


		<div class="form-group">
		    <?php echo Form::label('Nombre'); ?>

		    <?php echo Form::text('name', null, 
		        array('required', 
		              'class'=>'form-control', 
		              'placeholder'=>'Ingrese su nombre')); ?>

		</div>

		<div class="form-group">
		    <?php echo Form::label('Email'); ?>

		    <?php echo Form::text('email', null, 
		        array('required', 
		              'class'=>'form-control', 
		              'placeholder'=>'Ingrese su email. Pronto recibira su respuesta.')); ?>

		</div>

		<div class="form-group">
		    <?php echo Form::label('Ingrese su mensaje'); ?>

		    <?php echo Form::textarea('message', null, 
		        array('required', 
		              'class'=>'form-control', 
		              'placeholder'=>'Hola FGM Ingenieria...')); ?>

		</div>

		<div class="form-group">
		    <?php echo Form::submit('Enviar!', ['class'=>'btn btn-primary']); ?>

		</div>

    <?php echo e(Form::close()); ?> 



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>