<?php $__env->startSection('head'); ?>
  <title>Inicio</title>
  <meta name="description" content="servicios">
  <meta name="keywords" content="FGMIngenieria, ingenieria, servicios">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="row">
        <div class="col-lg-4">
          <img src="<?php echo e(asset('/images/azul.jpg')); ?>" alt="Consultoria" width="140" height="140"> <!-- VER ALT -->
          <h2>Consultoria</h2>
          <p>El asesoramiento en la resolución de problemas asociados a la reingeniería de productos es el primer paso para lograr un producto con mayor valor agregado. El área de FGM Ingeniería destinada a la consultoría y asesoramiento de empresas se basa en el relevamiento de planta, estudios de ingeniería y factibilidad de proyectos estructurales y mecánicos. A su vez, contamos con experiencia en instalaciones neumáticas e hidráulicas, logrando el acceso a sistemas cada vez con mayor grado de perfeccionamiento.</p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img src="<?php echo e(asset('/images/azul.jpg')); ?>" alt="Disenos por computadora" width="140" height="140">
          <h2>Disenos asistidos por computadora</h2>
          <p>Esta área de FGM Ingeniería se dedica al diseño asistido por computadora. Nos destacamos por brindar soluciones a sistemas de gran complejidad, centrándonos en la innovación de soluciones para el diseño de diferentes componentes y estructuras metálicas... </p>
          <p><a class="btn btn-default" href="<?php echo e(url('servicio/1')); ?>" role="button">Ver detalles &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img src="<?php echo e(asset('/images/azul.jpg')); ?>" alt="FEM" width="140" height="140">
          <h2>Análisis por método de elementos finitos</h2>
          <p>Encauzados en el grandioso camino de la ingeniería moderna, FGM Ingeniería provee el servicio de análisis por método de elementos finitos para el  estudio numerico de componentes, sistemas, estructuras, frecuencias naturales y modos de vibrar, análisis tensional...</p>
          <p><a class="btn btn-default" href="<?php echo e(url('servicio/2')); ?>" role="button">Ver detalles &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>